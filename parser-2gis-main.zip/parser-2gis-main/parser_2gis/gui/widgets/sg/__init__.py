from .rubrics_tree import RubricsTree

__all__ = [
    'RubricsTree',
]
